package LeoCTD.Qtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QToolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
