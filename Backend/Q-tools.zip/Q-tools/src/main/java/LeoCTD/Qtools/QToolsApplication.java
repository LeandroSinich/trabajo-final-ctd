package LeoCTD.Qtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QToolsApplication.class, args);
	}

}
