package LeoCTD.Quetools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueToolsApplication.class, args);
	}

}
